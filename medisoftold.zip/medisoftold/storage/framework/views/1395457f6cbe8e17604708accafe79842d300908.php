<!-- Bootstrap 3.3.7 -->
<?php echo e(Html::script('public/assets/bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>

<!-- SlimScroll -->
<?php echo e(Html::script('public/assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js')); ?>

<!-- FastClick -->
<?php echo e(Html::script('public/assets/bower_components/fastclick/lib/fastclick.js')); ?>

<?php echo e(Html::script('public/assets/dist/js/adminlte.min.js')); ?>

<!-- AdminLTE for demo purposes -->
<?php echo e(Html::script('public/assets/dist/js/demo.js')); ?>


	<!-- We Include js files when needed only -->
	<?php echo $__env->yieldContent('extra-js'); ?>

</body>
</html>
